package com.paypal.bfs.test.bookingserv.bookingserv.util;

import com.paypal.bfs.test.bookingserv.api.entity.AddressEntity;
import com.paypal.bfs.test.bookingserv.api.entity.BookingEntity;
import com.paypal.bfs.test.bookingserv.api.model.Address;
import com.paypal.bfs.test.bookingserv.api.model.Booking;
import org.apache.commons.lang.StringUtils;
import org.springframework.http.HttpStatus;
import org.springframework.web.server.ResponseStatusException;

import java.util.ArrayList;
import java.util.List;

public class BookingUtil {
    public static BookingEntity convertDtoToEntity(Booking booking){
        return BookingEntity.builder().id(booking.getId())
                .firstName(booking.getFirstName())
                .lastName(booking.getLastName())
                .checkin(booking.getCheckin())
                .checkout(booking.getCheckout())
                .deposit(booking.getDeposit())
                .totalprice(booking.getTotalprice())
                .address(convertAddressDtoToEntity(booking.getAddress()))
                .build();

    }

    public static AddressEntity convertAddressDtoToEntity(Address address){
        return AddressEntity.builder()
                .line1(address.getLine1())
                .line2(address.getLine2())
                .city(address.getCity())
                .state(address.getState())
                .country(address.getCountry())
                .zipCode(address.getZipCode())
                .build();

    }

    public static Address convertAddressEntityToDto(AddressEntity addressEntity){
        Address address = new Address();
        address.setLine1(addressEntity.getLine1());
        address.setLine2(addressEntity.getLine2());
        address.setCity(addressEntity.getCity());
        address.setState(addressEntity.getState());
        address.setCountry(addressEntity.getCountry());
        address.setZipCode(addressEntity.getZipCode());
        return address;
    }

    public static Booking convertEntityToDto(BookingEntity bookingEntity){
        Booking booking = new Booking();
        booking.setId(bookingEntity.getId());
        booking.setFirstName(bookingEntity.getFirstName());
        booking.setLastName(bookingEntity.getLastName());
        booking.setCheckin(bookingEntity.getCheckin());
        booking.setCheckout(bookingEntity.getCheckout());
        booking.setDeposit(bookingEntity.getDeposit());
        booking.setTotalprice(bookingEntity.getTotalprice());
        booking.setAddress(convertAddressEntityToDto(bookingEntity.getAddress()));
        return booking;
    }

    public static List<Booking> convertListEntityToDto(List<BookingEntity> entityList){
        List<Booking> allBookings = new ArrayList<>();
        entityList.forEach(entity->{
            allBookings.add(convertEntityToDto(entity));
        });
        return allBookings;
    }

}
