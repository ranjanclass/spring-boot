package com.paypal.bfs.test.bookingserv.bookingserv.validator;

import com.paypal.bfs.test.bookingserv.api.model.Booking;
import lombok.RequiredArgsConstructor;
import org.apache.commons.lang.StringUtils;
import org.springframework.context.MessageSource;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;
import org.springframework.web.server.ResponseStatusException;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

@Component
@RequiredArgsConstructor
public class BookingValidator {

    private final MessageSource messageSource;

    public boolean validateBooking(Booking booking){
        List<String> allErrors = new ArrayList<>();
        if(booking.getCheckin().compareTo(booking.getCheckout()) >0 ){
            allErrors.add(messageSource.getMessage("api.request.booking.checkin.comparison",null, Locale.US));
        }
        if(booking.getCheckin().before(new Date())){
            allErrors.add(messageSource.getMessage("api.request.booking.checkin.today",null, Locale.US));
        }
        if(booking.getTotalprice()<0 || booking.getDeposit() < 0){
            allErrors.add(messageSource.getMessage("api.request.booking.price",null, Locale.US));

        }
        if(booking.getAddress()==null){
            allErrors.add(messageSource.getMessage("api.request.booking.address",null, Locale.US));

        }
        if(StringUtils.isEmpty(booking.getAddress().getLine1())){
            allErrors.add(messageSource.getMessage("api.request.booking.address.line1",null, Locale.US));

        }
        if(StringUtils.isEmpty(booking.getAddress().getCity())){
            allErrors.add(messageSource.getMessage("api.request.booking.address.city",null, Locale.US));

        }
        if(StringUtils.isEmpty(booking.getAddress().getState())){
            allErrors.add(messageSource.getMessage("api.request.booking.address.state",null, Locale.US));

        }
        if(StringUtils.isEmpty(booking.getAddress().getCountry())){
            allErrors.add(messageSource.getMessage("api.request.booking.address.country",null, Locale.US));

        }
        //zip_code is fix for 6 (India)
        if(booking.getAddress().getZipCode().toString().length()!=6){
            allErrors.add(messageSource.getMessage("api.request.booking.address.zipcode",null, Locale.US));

        }
        if(StringUtils.isEmpty(booking.getFirstName())){
            allErrors.add(messageSource.getMessage("api.request.booking.firstName",null, Locale.US));

        }
        if(StringUtils.isEmpty(booking.getLastName())){
            allErrors.add(messageSource.getMessage("api.request.booking.lastName",null, Locale.US));

        }

        if(allErrors.size()>0){
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST,allErrors.toString());
        }
        return true;
    }
}
