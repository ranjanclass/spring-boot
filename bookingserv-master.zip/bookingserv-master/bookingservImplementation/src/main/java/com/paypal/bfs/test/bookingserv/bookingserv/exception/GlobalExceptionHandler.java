package com.paypal.bfs.test.bookingserv.bookingserv.exception;

import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.FieldError;
import org.springframework.web.HttpRequestMethodNotSupportedException;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.method.annotation.MethodArgumentTypeMismatchException;
import org.springframework.web.server.ResponseStatusException;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

import javax.persistence.QueryTimeoutException;
import javax.validation.ConstraintViolation;
import javax.validation.ConstraintViolationException;
import java.util.HashMap;
import java.util.Map;

@ControllerAdvice
public class GlobalExceptionHandler extends ResponseEntityExceptionHandler {

    @ExceptionHandler(ConstraintViolationException.class)
    public ResponseEntity<Object> handleConstraintValidation(QueryTimeoutException queryTimeoutException){
        return new ResponseEntity<Object>(HttpStatus.BAD_REQUEST);
    }


    @ExceptionHandler(QueryTimeoutException.class)
    public ResponseEntity<Object> handleQueryTimeoutException(QueryTimeoutException queryTimeoutException){
        return new ResponseEntity<Object>(queryTimeoutException.getQuery(), HttpStatus.REQUEST_TIMEOUT);
    }

    @ExceptionHandler(MethodArgumentTypeMismatchException.class)
    protected ResponseEntity<Object> handleMethodArgumentTypeMismatch(MethodArgumentTypeMismatchException ex) {
        Map<String, Object> body = new HashMap<>();
        body.put("error", ex.getMessage());
        return new ResponseEntity<>(body, HttpStatus.BAD_REQUEST);
    }

    @Override
    protected ResponseEntity<Object> handleHttpRequestMethodNotSupported(
            HttpRequestMethodNotSupportedException ex,
            HttpHeaders headers,
            HttpStatus status,
            WebRequest request) {
        StringBuilder builder = new StringBuilder();
        builder.append(ex.getMethod());
        builder.append(
                " method is not supported for this request. Supported methods are ");
        ex.getSupportedHttpMethods().forEach(t -> builder.append(t + " "));

        return new ResponseEntity<Object>(ex,HttpStatus.METHOD_NOT_ALLOWED);
    }

    @ExceptionHandler({ ResponseStatusException.class })
    public ResponseStatusException handleAll(ResponseStatusException ex, WebRequest request) {
        if(ex.getStatus()!=null) throw ex;
        throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR,ex.getLocalizedMessage());
    }
}
