package com.paypal.bfs.test.bookingserv.bookingserv.impl;

import com.paypal.bfs.test.bookingserv.BookingRepository;
import com.paypal.bfs.test.bookingserv.TokenRepository;
import com.paypal.bfs.test.bookingserv.api.BookingResource;
import com.paypal.bfs.test.bookingserv.api.entity.BookingEntity;
import com.paypal.bfs.test.bookingserv.api.entity.Token;
import com.paypal.bfs.test.bookingserv.api.model.Booking;
import com.paypal.bfs.test.bookingserv.bookingserv.util.BookingUtil;
import com.paypal.bfs.test.bookingserv.bookingserv.validator.BookingValidator;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ResponseStatusException;

import javax.persistence.EntityExistsException;
import javax.persistence.NonUniqueResultException;
import javax.transaction.Transactional;
import java.util.List;

@Service
@RequiredArgsConstructor
public class BookingResourceImpl implements BookingResource {

    private final BookingRepository bookingRepository;
    private final TokenRepository tokenRepository;
    private final BookingValidator bookingValidator;

    @Override
    @Transactional
    public ResponseEntity<Booking> create(Booking booking,String token) {
        try{
            bookingValidator.validateBooking(booking);

            Token fetchedToken = tokenRepository.findByToken(token);

            BookingEntity savedBooking;
            if(fetchedToken == null){
                savedBooking = bookingRepository.save(BookingUtil.convertDtoToEntity(booking));
                fetchedToken = Token.builder().token(token).bookingId(savedBooking.getId()).build();
                tokenRepository.save(fetchedToken);
            }else{
                savedBooking = bookingRepository.findById(fetchedToken.getBookingId());
            }
            return new ResponseEntity<>(BookingUtil.convertEntityToDto(savedBooking), HttpStatus.CREATED);

        }
        catch (EntityExistsException entityExistsException){
            throw new ResponseStatusException(HttpStatus.CONFLICT);
        }
    }

    @Override
    public ResponseEntity<List<Booking>> getAllBooking() {
        try {
            List<BookingEntity> allBookings = bookingRepository.findAll();
            return new ResponseEntity<>(BookingUtil.convertListEntityToDto(allBookings), HttpStatus.FOUND);
        }catch (NonUniqueResultException e){
            throw new ResponseStatusException(HttpStatus.CONFLICT);
        }
    }
}
