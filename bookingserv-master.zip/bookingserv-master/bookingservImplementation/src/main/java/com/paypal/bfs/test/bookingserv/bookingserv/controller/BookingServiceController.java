package com.paypal.bfs.test.bookingserv.bookingserv.controller;

import com.paypal.bfs.test.bookingserv.api.BookingResource;
import com.paypal.bfs.test.bookingserv.api.model.Booking;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;

import javax.validation.Valid;
import java.util.List;
@RestController
@RequiredArgsConstructor
@Validated
public class BookingServiceController {

    private final BookingResource bookingResource;

    @PostMapping(value = "/create")
    public ResponseEntity<Booking> createBooking(@Valid @RequestBody Booking booking,@RequestHeader("booking-token") String token){
        return bookingResource.create(booking,token);
    }

    @GetMapping(value = "/getAllBookings")
    public ResponseEntity<List<Booking>> getAllBookings(){
        return bookingResource.getAllBooking();
    }

}
