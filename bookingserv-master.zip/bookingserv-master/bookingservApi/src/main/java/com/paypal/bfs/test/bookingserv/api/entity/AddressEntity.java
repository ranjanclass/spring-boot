package com.paypal.bfs.test.bookingserv.api.entity;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyDescription;
import lombok.Builder;
import lombok.Data;

import javax.persistence.*;

@Entity
@Table(name = "AddressEntity")
@Builder
@Data
public class AddressEntity {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;
    private String line1;
    private String line2;
    private String city;
    private String state;
    private String country;
    private Integer zipCode;
}
