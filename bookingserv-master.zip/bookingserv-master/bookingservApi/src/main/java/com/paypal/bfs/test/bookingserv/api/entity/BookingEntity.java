package com.paypal.bfs.test.bookingserv.api.entity;

import lombok.Builder;
import lombok.Data;

import javax.persistence.*;
import java.util.Date;

@Entity
@Table(name="BookingEntity")
@Data
@Builder
public class BookingEntity {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Integer id;
    private String firstName;
    private String lastName;
    private Date checkin;
    private Date checkout;
    private Double totalprice;
    private Double deposit;
    @OneToOne(cascade = CascadeType.ALL)
    private AddressEntity address;
}
