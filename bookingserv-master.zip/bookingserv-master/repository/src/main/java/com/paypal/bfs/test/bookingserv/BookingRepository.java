package com.paypal.bfs.test.bookingserv;

import com.paypal.bfs.test.bookingserv.api.entity.BookingEntity;
import com.paypal.bfs.test.bookingserv.api.model.Booking;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface BookingRepository extends CrudRepository<BookingEntity,Long> {
    List<BookingEntity> findAll();
    BookingEntity findById(Integer id);
}
