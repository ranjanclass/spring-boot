package com.paypal.bfs.test.bookingserv;

import com.paypal.bfs.test.bookingserv.api.entity.Token;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface TokenRepository extends CrudRepository<Token,Long> {
    Token findByToken(String token);
}
