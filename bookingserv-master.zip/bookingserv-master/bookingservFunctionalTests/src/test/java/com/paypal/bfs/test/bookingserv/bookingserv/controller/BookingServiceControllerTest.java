package com.paypal.bfs.test.bookingserv.bookingserv.controller;

import com.paypal.bfs.test.bookingserv.bookingserv.BookingServApplication;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.context.MessageSource;
import org.springframework.http.MediaType;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import java.util.Arrays;
import java.util.Locale;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;


@RunWith(SpringRunner.class)
@SpringBootTest(classes = BookingServApplication.class)
@AutoConfigureMockMvc
@TestPropertySource(
        locations = {"classpath:application-it.properties"})
public class BookingServiceControllerTest {

    @Autowired
    private MockMvc mvc;

    @Autowired
    private BookingServiceController bookingServiceController;

    @Autowired
    private MessageSource messageSource;

    @Before
    public void setup() {
        mvc = MockMvcBuilders.standaloneSetup(bookingServiceController).build();
    }


    @Test
    public void getAllBooking() throws Exception {
        mvc.perform(get("/getAllBookings"))
                .andExpect(status().isFound());
    }

    @Test
    public void create() throws Exception {
        String body1 = "{\n" +
                "    \"first_name\" : \"NewTest\",\n" +
                "    \"last_name\" : \"NewKumar\",\n" +
                "    \"checkin\" : \"2021-08-04T09:25:23.112+0000\",\n" +
                "    \"checkout\" : \"2021-08-08T09:25:23.112+0000\",\n" +
                "    \"totalprice\" : 2000.00,\n" +
                "    \"deposit\" : 200.00,\n" +
                "    \"address\":{\n" +
                "        \"line1\" : \"cool road one\",\n" +
                "        \"line2\" : \"cool road two\",\n" +
                "        \"city\" : \"nice Hyd\",\n" +
                "        \"state\": \"super Tel\",\n" +
                "        \"country\": \"best IN\",\n" +
                "        \"zip_code\" : \"702010\"\n" +
                "    }\n" +
                "}";
        String body2 = "{\n" +
                "    \"first_name\" : \"SecondTest\",\n" +
                "    \"last_name\" : \"Second NewKumar\",\n" +
                "    \"checkin\" : \"2021-08-07T09:25:23.112+0000\",\n" +
                "    \"checkout\" : \"2021-08-09T09:25:23.112+0000\",\n" +
                "    \"totalprice\" : 2000.00,\n" +
                "    \"deposit\" : 200.00,\n" +
                "    \"address\":{\n" +
                "        \"line1\" : \"Second cool road one\",\n" +
                "        \"line2\" : \"Second cool road two\",\n" +
                "        \"city\" : \"Second nice Hyd\",\n" +
                "        \"state\": \"Second super Tel\",\n" +
                "        \"country\": \"Second CN\",\n" +
                "        \"zip_code\" : \"712010\"\n" +
                "    }\n" +
                "}";

        mvc.perform(post("/create").contentType(MediaType.APPLICATION_JSON)
                    .content(body1)
                    .header("Content-Type", "application/json")
                    .header("booking-token","3245"))
                .andExpect(status().isCreated())
                .andExpect(MockMvcResultMatchers.jsonPath("$.first_name").value("NewTest"));

        mvc.perform(post("/create").contentType(MediaType.APPLICATION_JSON)
                .content(body2)
                .header("Content-Type", "application/json")
                .header("booking-token","32451"))
                .andExpect(status().isCreated())
                .andExpect(MockMvcResultMatchers.jsonPath("$.first_name").value("SecondTest"));

        mvc.perform(get("/getAllBookings"))
                .andExpect(status().isFound())
                .andExpect(MockMvcResultMatchers.jsonPath("$").hasJsonPath())
                .andExpect(MockMvcResultMatchers.jsonPath("$").isArray())
                .andExpect(MockMvcResultMatchers.jsonPath("$.[0].first_name").value("NewTest"))
                .andExpect(MockMvcResultMatchers.jsonPath("$.[1].first_name").value("SecondTest"))
                .andExpect(MockMvcResultMatchers.jsonPath("$.[1].address.line1").value("Second cool road one"));


    }

    //mandatory first_name and last_name missing
    //Sends 400 BAD Request
    @Test
    public void createFail() throws Exception {
        String body1 = "{\"last_name\":\"NewKumar\",\"checkin\":\"10\",\"checkout\":\"15\",\"totalprice\":2000,\"deposit\":200,\"address\":{\"line1\":\"cool road one\",\"line2\":\"cool road two\",\"city\":\"nice Hyd\",\"state\":\"super Tel\",\"country\":\"best IN\",\"zip_code\":\"702010\"}}";
        String body2 = "{\"first_name\":\"SecondBody\",\"checkin\":\"20\",\"checkout\":\"19\",\"totalprice\":4000,\"deposit\":400,\"address\":{\"line1\":\"second cool road one\",\"line2\":\"second cool road two\",\"city\":\"second Hyd\",\"state\":\"super Tel\",\"country\":\"best IN\",\"zip_code\":\"712010\"}}";
        mvc.perform(post("/create").contentType(MediaType.APPLICATION_JSON)
                .content(body1)
                .header("Content-Type", "application/json")
                .header("booking-token","3245"))
                .andExpect(status().is4xxClientError());

        MvcResult result = mvc.perform(post("/create").contentType(MediaType.APPLICATION_JSON)
                .content(body2)
                .header("Content-Type", "application/json")
                .header("booking-token","3245"))
                .andExpect(status().isBadRequest())
                .andReturn();
        Assert.assertEquals(result.getResponse().getErrorMessage(), Arrays.asList(messageSource.getMessage("api.request.booking.checkin.comparison",null, Locale.US),(messageSource.getMessage("api.request.booking.checkin.today",null, Locale.US)),messageSource.getMessage("api.request.booking.lastName",null, Locale.US)).toString());

    }

    @Test
    public void createPriceNegative() throws Exception {
        String body1 = "{\n" +
                "    \"first_name\" : \"NewTest\",\n" +
                "    \"last_name\" : \"NewKumar\",\n" +
                "    \"checkin\" : \"2021-08-04T09:25:23.112+0000\",\n" +
                "    \"checkout\" : \"2021-08-08T09:25:23.112+0000\",\n" +
                "    \"totalprice\" : -2000.00,\n" +
                "    \"deposit\" : 200.00,\n" +
                "    \"address\":{\n" +
                "        \"line1\" : \"cool road one\",\n" +
                "        \"line2\" : \"cool road two\",\n" +
                "        \"city\" : \"nice Hyd\",\n" +
                "        \"state\": \"super Tel\",\n" +
                "        \"country\": \"best IN\",\n" +
                "        \"zip_code\" : \"702010\"\n" +
                "    }\n" +
                "}";
        MvcResult result = mvc.perform(post("/create").contentType(MediaType.APPLICATION_JSON)
                .content(body1)
                .header("Content-Type", "application/json")
                .header("booking-token","3245"))
                .andExpect(status().isBadRequest())
                .andReturn();
        Assert.assertEquals(result.getResponse().getErrorMessage(), Arrays.asList(messageSource.getMessage("api.request.booking.price",null, Locale.US)).toString());


    }

    @Test
    public void createAddressMissing() throws Exception {
        String body1 = "{\n" +
                "    \"first_name\" : \"NewTest\",\n" +
                "    \"last_name\" : \"NewKumar\",\n" +
                "    \"checkin\" : \"2021-08-04T09:25:23.112+0000\",\n" +
                "    \"checkout\" : \"2021-08-08T09:25:23.112+0000\",\n" +
                "    \"totalprice\" : 2000.00,\n" +
                "    \"deposit\" : 200.00,\n" +
                "    \"address\":{\n" +
                "        \"line2\" : \"cool road two\",\n" +
                "        \"city\" : \"nice Hyd\",\n" +
                "        \"state\": \"super Tel\",\n" +
                "        \"country\": \"best IN\",\n" +
                "        \"zip_code\" : \"702010\"\n" +
                "    }\n" +
                "}";
        MvcResult result = mvc.perform(post("/create").contentType(MediaType.APPLICATION_JSON)
                .content(body1)
                .header("Content-Type", "application/json")
                .header("booking-token","3245"))
                .andExpect(status().isBadRequest())
                .andReturn();
        Assert.assertEquals(result.getResponse().getErrorMessage(), Arrays.asList(messageSource.getMessage("api.request.booking.address.line1",null, Locale.US)).toString());


    }

    @Test
    public void createIdempotent() throws Exception {
        String body1 = "{\n" +
                "    \"first_name\" : \"NewTest\",\n" +
                "    \"last_name\" : \"NewKumar\",\n" +
                "    \"checkin\" : \"2021-08-04T09:25:23.112+0000\",\n" +
                "    \"checkout\" : \"2021-08-08T09:25:23.112+0000\",\n" +
                "    \"totalprice\" : 2000.00,\n" +
                "    \"deposit\" : 200.00,\n" +
                "    \"address\":{\n" +
                "        \"line1\" : \"cool road one\",\n" +
                "        \"line2\" : \"cool road two\",\n" +
                "        \"city\" : \"nice Hyd\",\n" +
                "        \"state\": \"super Tel\",\n" +
                "        \"country\": \"best IN\",\n" +
                "        \"zip_code\" : \"702010\"\n" +
                "    }\n" +
                "}";
        String body2 = "{\n" +
                "    \"first_name\" : \"SecondTest\",\n" +
                "    \"last_name\" : \"Second NewKumar\",\n" +
                "    \"checkin\" : \"2021-08-07T09:25:23.112+0000\",\n" +
                "    \"checkout\" : \"2021-08-09T09:25:23.112+0000\",\n" +
                "    \"totalprice\" : 2000.00,\n" +
                "    \"deposit\" : 200.00,\n" +
                "    \"address\":{\n" +
                "        \"line1\" : \"Second cool road one\",\n" +
                "        \"line2\" : \"Second cool road two\",\n" +
                "        \"city\" : \"Second nice Hyd\",\n" +
                "        \"state\": \"Second super Tel\",\n" +
                "        \"country\": \"Second CN\",\n" +
                "        \"zip_code\" : \"712010\"\n" +
                "    }\n" +
                "}";

        mvc.perform(post("/create").contentType(MediaType.APPLICATION_JSON)
                .content(body1)
                .header("Content-Type", "application/json")
                .header("booking-token","3245"))
                .andExpect(status().isCreated())
                .andExpect(MockMvcResultMatchers.jsonPath("$.first_name").value("NewTest"));

        mvc.perform(post("/create").contentType(MediaType.APPLICATION_JSON)
                .content(body1)
                .header("Content-Type", "application/json")
                .header("booking-token","3245"))
                .andExpect(status().isCreated())
                .andExpect(MockMvcResultMatchers.jsonPath("$.first_name").value("NewTest"));

        mvc.perform(post("/create").contentType(MediaType.APPLICATION_JSON)
                .content(body1)
                .header("Content-Type", "application/json")
                .header("booking-token","3245"))
                .andExpect(status().isCreated())
                .andExpect(MockMvcResultMatchers.jsonPath("$.first_name").value("NewTest"));

        mvc.perform(post("/create").contentType(MediaType.APPLICATION_JSON)
                .content(body2)
                .header("Content-Type", "application/json")
                .header("booking-token","32451"))
                .andExpect(status().isCreated())
                .andExpect(MockMvcResultMatchers.jsonPath("$.first_name").value("SecondTest"));

        mvc.perform(get("/getAllBookings"))
                .andExpect(status().isFound())
                .andExpect(MockMvcResultMatchers.jsonPath("$").hasJsonPath())
                .andExpect(MockMvcResultMatchers.jsonPath("$").isArray())
                .andExpect(MockMvcResultMatchers.jsonPath("$.[0].first_name").value("NewTest"))
                .andExpect(MockMvcResultMatchers.jsonPath("$.[1].first_name").value("SecondTest"))
                .andExpect(MockMvcResultMatchers.jsonPath("$.[1].address.line1").value("Second cool road one"));


    }


}
